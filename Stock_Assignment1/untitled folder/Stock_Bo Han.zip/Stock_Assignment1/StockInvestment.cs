﻿using System;
namespace Stock_Assignment1
{
    public class StockInvestment
    {
        public StockInvestment()
        {
        }
    }
}

﻿using System;
using System.Collections.Generic;
namespace Bo_Han_Assignment2
{
    public interface IReadable
    {
        List<string> ReadAll(string fileName);  
    }
}

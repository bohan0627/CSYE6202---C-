﻿using System;
namespace Bo_Han_Assignment2
{
    public abstract class AbstractStock
    {
        public AbstractStock()
        {
        }

        public abstract double Update(int percentChange);
    }
}
